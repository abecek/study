import matplotlib.pyplot as plt
counter = 0

class SimpleSet:
    
    def __init__(self, *args): #konstruktor. Metody specjalne zaczynaja sie i koncza __ (dwa podkreslenia). *args - * oznacza 0 lub wiecej wartosci. Args to zwykla tablica
        self._tab = [] # _tab to taka konwencja nazewnictwa. Informujemy uzytkownika ze tego pola nie powinno sie tykac (w sensie ze jest prywatne)
        for v in args: self.insert(v) #petla iteruje po wartosciach z tablicy (nie interesuja nas indeksy)

    def find(self,val): #self to taki this. Zawsze trzeba go pisac jawnie
        return self._find(val) != -1 #zwracam indeks jest jest a jak nie to -1
    
    def insert(self,val):
        if not self.find(val):
            self._tab.append(val)
    
    def erase(self,val):
        i = self._find(val)
        if i != -1:
            self._tab[i] = self._tab[-1] #tab[-1] to wskaznik na ostatni element tablicy
            self._tab.pop() #del self._tab[i] - usunie element i od razu przesunie elementy w lewo o 1 miejsce. pop() usuwa ostatni element z konca
    
    def _find(self,val): #prywatna, pomocnicza funkcja find
        global counter 
        for i, v in enumerate(self._tab): #enumerate zamienia cos na sekwencje par wartosci np. 0 = a, 1 = b itd. Mozna nawet iterowac w ten sposob plik i wtedy dostajemy cale linijki
            counter += 1
            if v == val:
                return i
        return -1
    
    def __str__(self):
        return str(self._tab)
    
    def __repr__(self):
        return "SimpleSet({})".format(str(self)[1:-1]) #Wyciagamy wszystko od indeksu od indeksu 1 do znaku o indeksie przedostatnim (bez nawiasow kwadratowych)
        #return "SimpleSet({})".format(", ".join(repr(v) for v in self._tab)) #Drugi sposob. Join przyjmuje sekwencje wartosci, zlacza i a pomiedzy nie wrzuca ", " ktory wpisalismy.

    def __len__(self): #dlugosc tablicy
        return len(self._tab)


class EmptyCell: pass #puste klasy ktore mozna wykorzytac jako znaki specjalne w projekcie
class DeletedCell: pass

s = None
print(s is EmptyCell)
s = EmptyCell #s jest teraz nowa nazwa dla klasy EmptyCell, nie obiektem tej klasy!
print(s is EmptyCell)
y = [EmptyCell] * 5 # *5 skleja te tablice ze soba 5 razy. Robi tablice pustych elementow
print(y)

s = SimpleSet(6, "zzz", 6)
s.insert(1);
s.insert(2);
s.erase(2);
s.insert("abc");
s.insert(None) #czyli NULL

print(s.find(1))
print(s.find(2))

print(str(s)) #metoda wypisujaca slownik. Daje strina przyjaznego dla czlowieka. Mozna nie uzywac str bo on to tez robi niejawnie. Wywoluje to metode specjalna dla tablicy __str__
print(repr(s)) #metoda wypisujaca slownik. Daje "stringa" (w zasadzie to krzaki ;p) do jego odtworzenia jako stringa w interpreterze.

print(len(s))

print(hash(1)) #domyslna funkcja hash. Mozna to wykorzystac w projekcie zamiast pisania wlasnej funkcji haszujacej!
print(hash("abc"))

s = SimpleSet()
x = []
y = []
for i in range(1,1001):
    x.append(i)
    s.insert(i)
    counter = 0
    s.find(0) #szukam 0 bo ono nie istnieje. Poznam w ten sposob zlozonosc pesymistyczna
    y.append(counter)
    
    

plt.plot(x,y, label="SimpleSet")
plt.xlabel("len")
plt.ylabel("liczba porwonan na wyszukiwanie")
plt.title("SimpleSet plot")
plt.legend()
plt.show()