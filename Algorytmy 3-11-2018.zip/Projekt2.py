"""
Wariant latwieszy i obowiazkowy (na 3):

Zaimplementowac 2 tablie haszujace:
- otwarte liniowe
- lancuchowe

Przyjmujemy ze:
- tablica ma stala dlugosc
- adresowanie jest liniowe (wstawianie pod kolejne indeksy)
- kasowanie to wstawianie wartowsci specjalnej itd.
- bez rozszerzania tablicy

---------------------------------------------------
Dwa rozszerzenia na 5 (kazde rozszerzenie to ocena w gore o 1):
Mozna dorzucic rehashowanie (jesli ilosc wstawionych elementow przekracza 60% jej pojemnosci, to przepisujemy jej elementy do tablicy 2x wiekszej i podmieniamy).
Mozna zrobic hashowanie podwojne.
Otwarte liniowe mozna zrobic kasowanie z przesuwaniem elementow
Trzecia tablica moze byc jako kolejne rozszerzenie

Do tego jeszcze wykres (obowiazkowo):
- X - liczba elementow w tablicy
- Y - liczba porownan wykonana przez operacje find (np. dla wartosci ktorej nie ma w tablicy)

Piszemy z uzyciem wlasnych klas

"""